"""
Agentic Fabric CLI Tool

A command-line interface for managing Agentic Fabric resources including
agents, tools, MCP servers, and administrative operations.
"""

__version__ = "1.0.0" 